#################################################################
# Taller "Análisis de datos espaciales en salud" (CIBERESP 2026)
# Sesiones de Miguel Rodríguez Barranco
# 00. Preparación del entorno
#
# En PositCloud este script ya está ejecutado en el proyecto base:
# basta con hacer una copia del proyecto ("Save a permanent copy").
# Si trabajas en tu ordenador, ejecútalo una sola vez.
#################################################################

paquetes <- c("sf",       # datos vectoriales (sustituye a sp, rgdal, rgeos y maptools)
              "mapsf",    # mapas temáticos (sucesor de cartography)
              "ggplot2",  # gráficos y mapas con geom_sf()
              "dplyr",    # manipulación de tablas
              "mapview",  # mapas interactivos
              "gstat")    # interpolación espacial (solo para el anexo del script 01)

instalar <- paquetes[!paquetes %in% rownames(installed.packages())]
if (length(instalar) > 0) install.packages(instalar)

# Comprobación: deben cargarse todos sin error
invisible(lapply(paquetes, library, character.only = TRUE))

# Versiones de las librerías geográficas que usa sf por debajo (GEOS, GDAL, PROJ)
sf_extSoftVersion()[c("GEOS", "GDAL", "PROJ")]
