#################################################################
# Taller "Análisis de datos espaciales en salud" (CIBERESP 2026)
# Sesión 3. Creación de mapas temáticos
# Miguel Rodríguez Barranco (EASP, ibs.GRANADA, CIBERESP)
#################################################################
#
# CÓMO USAR ESTE SCRIPT
#   Ejecuta las líneas de una en una (o por bloques) con Ctrl + Enter
#   (Cmd + Enter en Mac) y fíjate en lo que aparece en la consola y en
#   la pestaña "Plots". Las líneas que empiezan por # son comentarios:
#   R no las ejecuta, están para explicarte cada paso.
#
# QUÉ VAMOS A HACER
#   Responderemos a varias preguntas de salud con el tipo de mapa
#   adecuado para cada una. Trabajamos en dos escenarios:
#
#   A. España por provincias
#      1. Leer un mapa en R
#      2. Mortalidad por cáncer ............ mapa de coropletas
#      3. Número de suicidios .............. mapa de símbolos proporcionales
#      4. Número de suicidios .............. mapa de densidad de puntos
#
#   B. Granada capital
#      5. Domicilio de casos de cáncer ..... mapa de puntos (coordenadas X, Y)
#      6. ¿Dónde se agrupan los casos? ..... mapa de calor
#      7. Exposición al tráfico ............ superficie continua (interpolación)
#      8. Ver los casos sobre un callejero . mapa interactivo
#      9. Guardar un mapa como imagen
#
# Trabajamos dentro del proyecto de RStudio, así que
# R ya sabe dónde están las carpetas Datos y Shapefiles.
#################################################################


#================================================================
# 0. PREPARACIÓN: CARGAR LOS PAQUETES
#================================================================
# Un paquete es un conjunto de funciones que amplía lo que R sabe
# hacer. Ya están instalados (script 00), pero hay que cargarlos en
# cada sesión con library().

library(sf)       # leer y manejar mapas (capas geográficas)
library(dplyr)    # manejar tablas: filtrar filas, unir tablas
library(mapsf)    # dibujar mapas temáticos
library(gstat)    # interpolación (apartado 7)
library(mapview)  # mapas interactivos (apartado 8)


#################################################################
#                                                               #
#   ESCENARIO A. ESPAÑA POR PROVINCIAS                          #
#                                                               #
#################################################################

#================================================================
# 1. LEER UN MAPA EN R
#================================================================
# Los mapas suelen venir en formato "shapefile": varios ficheros con
# el mismo nombre y distinta extensión (.shp, .dbf, .shx, .prj) que
# siempre deben ir juntos. Basta con indicar el .shp.
#
# st_read() lee el mapa y lo guarda en un objeto que llamamos
# "provincias". quiet = TRUE evita mensajes técnicos en la consola.

provincias <- st_read("Shapefiles/Provincias_ETRS89_30N.shp", quiet = TRUE)

# Para R, un mapa es una tabla normal con una columna especial,
# "geometry", que guarda la forma de cada provincia.
# Cada fila es una provincia. Miramos las primeras filas:

head(provincias)

# Las columnas que nos interesan son "Codigo" (código de provincia del
# INE: "01" Álava, "02" Albacete...) y "Texto" (nombre de la provincia).

# Dibujamos solo los contornos. st_geometry() se queda con la forma
# y deja fuera el resto de columnas.

plot(st_geometry(provincias))


#================================================================
# 2. MAPA DE COROPLETAS: MORTALIDAD POR CÁNCER
#================================================================
# PREGUNTA DE SALUD
#   ¿Hay diferencias entre provincias en la mortalidad por cáncer?
#
# DATOS
#   Mapa de provincias (ya leído) y una tabla con la mortalidad por
#   cáncer de 2016 en cada provincia: casos, población y tasa bruta
#   por 100.000 habitantes (fichero Datos/mort_cancer_2016.csv).
#
# TIPO DE MAPA
#   Coropletas: cada provincia se colorea según el valor de su tasa.
#   Es el mapa adecuado para tasas o proporciones, que ya tienen en
#   cuenta el tamaño de la población. No sirve para números absolutos
#   de casos: las provincias más pobladas saldrían siempre oscuras.
#----------------------------------------------------------------

# Paso 1. Leer la tabla de mortalidad.
# Los ficheros .csv de este taller usan ";" para separar columnas y
# "," para los decimales: por eso usamos read.csv2().
# colClasses obliga a leer el código de provincia como texto. Si no,
# R lo lee como número y "01" se convierte en 1, y entonces no
# coincidiría con el código del mapa.

mortalidad <- read.csv2("Datos/mort_cancer_2016.csv",
                        colClasses = c(cod_prov = "character"))

head(mortalidad)

# Paso 2. Unir la tabla al mapa.
# left_join() añade a cada provincia del mapa las columnas de la tabla,
# emparejando las filas por el código de provincia, que en el mapa se
# llama "Codigo" y en la tabla "cod_prov".

provincias <- left_join(provincias, mortalidad, by = c("Codigo" = "cod_prov"))

head(provincias)    # ahora el mapa incluye casos, pobl y tasa_bruta

# Paso 3. Quedarnos con las provincias peninsulares.
# Canarias y las ciudades autónomas quedan muy lejos y hacen que la
# península se vea pequeña. filter() se queda con las filas que
# cumplen una condición: aquí, que el código NO (!) esté en la lista
# de Baleares (07), Las Palmas (35), Santa Cruz de Tenerife (38),
# Ceuta (51) y Melilla (52).

peninsula <- filter(provincias, !Codigo %in% c("07", "35", "38", "51", "52"))

plot(st_geometry(peninsula))

# Paso 4. Dibujar el mapa de coropletas.
# mf_map() es la función de mapsf para dibujar mapas temáticos.
# Primero, la versión más sencilla: le decimos qué mapa (peninsula),
# qué variable (tasa_bruta) y qué tipo de mapa ("choro" = coropletas).

mf_map(peninsula, var = "tasa_bruta", type = "choro")

# Paso 5. Mejorar el mapa.
# Por defecto, mapsf decide los cortes entre colores y la paleta.
# Ahora los fijamos nosotros para que la leyenda sea fácil de leer:
#   breaks   = cortes entre categorías, en números redondos
#   pal      = paleta de colores (de claro a oscuro, de menor a mayor)
#   leg_pos  = posición de la leyenda
#   leg_title = título de la leyenda (\n significa salto de línea)
#   leg_val_rnd = 0 muestra los valores de la leyenda sin decimales
# Después añadimos título, fuente, escala y flecha del norte.

mf_map(peninsula,
       var       = "tasa_bruta",
       type      = "choro",
       breaks    = c(150, 200, 250, 300, 350, 400),
       pal       = "Oranges",
       leg_pos   = "right",
       leg_title = "Tasa bruta\n(x100.000)",
       leg_val_rnd = 0)
mf_title("Mortalidad por cáncer. España, 2016")
mf_credits("Fuente: INE. Defunciones según la causa de muerte")
mf_scale(size = 200)        # barra de escala de 200 km
mf_arrow(pos = "topright")  # flecha del norte

# Para interpretar: la tasa bruta no tiene en cuenta la edad. Las
# provincias más envejecidas (noroeste) tienen más mortalidad en
# parte porque tienen más personas mayores. Para comparar provincias
# de forma justa se usan tasas ajustadas por edad o razones de
# mortalidad estandarizadas, que se verán en el bloque de
# epidemiología espacial.


#================================================================
# 3. MAPA DE SÍMBOLOS PROPORCIONALES: NÚMERO DE SUICIDIOS
#================================================================
# PREGUNTA DE SALUD
#   ¿En qué provincias se concentra el mayor número de suicidios?
#   Interesa, por ejemplo, para dimensionar recursos de prevención.
#
# DATOS
#   Una tabla con el número de suicidios de 2016 en cada provincia
#   (fichero Datos/Suicidios 2016.csv).
#
# TIPO DE MAPA
#   Ahora tenemos números absolutos, no tasas. Para números absolutos
#   se usan símbolos (círculos) cuyo tamaño es proporcional al número
#   de casos. El círculo se coloca dentro de cada provincia.
#----------------------------------------------------------------

# Paso 1. Leer la tabla y unirla al mapa, igual que en el apartado 2.
# select() se queda solo con las columnas que necesitamos de la tabla.

suicidios <- read.csv2("Datos/Suicidios 2016.csv",
                       colClasses = c(cod_prov = "character"))

head(suicidios)

peninsula <- left_join(peninsula, select(suicidios, cod_prov, suic),
                       by = c("Codigo" = "cod_prov"))

# Paso 2. Dibujar el mapa en dos capas.
# Primero el fondo: las provincias en gris claro con bordes blancos.
# Después los círculos: type = "prop" (proporcional) sobre la variable
# "suic". inches fija el tamaño del círculo más grande.

mf_map(peninsula, col = "grey90", border = "white")
mf_map(peninsula,
       var       = "suic",
       type      = "prop",
       inches    = 0.3,
       col       = "steelblue",
       leg_pos   = "right",
       leg_title = "Nº de suicidios")
mf_title("Suicidios por provincia. España, 2016")

# Para interpretar: los círculos grandes coinciden con las provincias
# más pobladas (Madrid, Barcelona...). Este mapa responde a "dónde hay
# más casos", no a "dónde hay más riesgo". Para el riesgo haría falta
# una tasa y un mapa de coropletas como el del apartado 2.


#================================================================
# 4. MAPA DE DENSIDAD DE PUNTOS: NÚMERO DE SUICIDIOS
#================================================================
# PREGUNTA DE SALUD
#   La misma del apartado 3, con otra forma de verlo.
#
# DATOS
#   Los mismos: número de suicidios por provincia en 2016.
#
# TIPO DE MAPA
#   Densidad de puntos: cada punto representa 10 suicidios y se
#   coloca al azar dentro de su provincia. Da una impresión visual de
#   cantidad. Ojo: la posición de cada punto NO es real, solo indica
#   en qué provincia están los casos.
#----------------------------------------------------------------

# Paso 1. Calcular cuántos puntos corresponden a cada provincia.
# Dividimos entre 10 y redondeamos con round(). Por ejemplo, una
# provincia con 145 suicidios tendrá 15 puntos.

peninsula$n_puntos <- round(peninsula$suic / 10)

# Paso 2. Repartir los puntos al azar dentro de cada provincia.
# st_sample() genera puntos aleatorios dentro de cada polígono.
# set.seed() fija el azar para que a todos nos salga el mismo mapa.

set.seed(2026)
puntos <- st_sample(peninsula, size = peninsula$n_puntos)

# Paso 3. Dibujar: primero el fondo y después los puntos encima
# (add = TRUE significa "añadir al mapa que ya está dibujado").
# pch = 20 es un punto relleno y cex su tamaño.

mf_map(peninsula, col = "grey90", border = "white")
mf_map(puntos, pch = 20, cex = 0.5, col = "red", add = TRUE)
mf_title("Suicidios en España, 2016. Cada punto = 10 casos")


#################################################################
#                                                               #
#   ESCENARIO B. GRANADA CAPITAL                                #
#                                                               #
#################################################################
# Para los apartados 5 a 8 usamos un mismo supuesto:
#
#   Un registro de cáncer dispone del domicilio de 78 casos de cáncer
#   diagnosticados en Granada capital (son datos ficticios). Cada
#   domicilio se ha convertido en coordenadas (geocodificado).
#   Queremos ver dónde están, si se agrupan en alguna zona y si
#   coinciden con zonas de mucho tráfico.
#
# Como mapa de fondo usamos las secciones censales de Granada capital.
# La sección censal es la unidad territorial más pequeña con datos
# oficiales de población (entre 1.000 y 2.500 habitantes).

#================================================================
# 5. MAPA DE PUNTOS A PARTIR DE COORDENADAS X, Y
#================================================================
# PREGUNTA DE SALUD
#   ¿Dónde residen los casos de cáncer?
#
# DATOS
#   - Mapa de secciones censales de la provincia de Granada (2001).
#   - Tabla con un identificador y las coordenadas del domicilio de
#     cada caso (Datos/Casos.csv).
#
# TIPO DE MAPA
#   Mapa de puntos: un punto por caso, en su posición real.
#----------------------------------------------------------------

# Paso 1. Leer el mapa de secciones y quedarnos con Granada capital.
# El mapa trae todas las secciones de la provincia. Granada capital
# es el municipio con código "18087".

secciones <- st_read("Shapefiles/SeccCensalGranadaCensoNov2001_ED50.shp", quiet = TRUE)
granada   <- filter(secciones, codmun == "18087")

plot(st_geometry(granada))

# Paso 2. Leer la tabla de casos.

casos <- read.csv2("Datos/Casos.csv")

head(casos)

# Las columnas "long" y "lat" son las coordenadas del domicilio.
# A pesar de su nombre, no son longitud y latitud en grados: son
# coordenadas UTM, en metros. Por ahora R solo ve una tabla con
# números, todavía no sabe que son posiciones en un mapa.

# Paso 3. Convertir la tabla en un mapa de puntos.
# st_as_sf() necesita dos cosas:
#   coords = qué columnas tienen la coordenada X y la coordenada Y
#   crs    = el sistema de referencia en el que están esas coordenadas
# Unas coordenadas sin su sistema de referencia están incompletas,
# igual que una cifra sin sus unidades. Estas están en el sistema
# "ED50 / UTM zona 30N", cuyo código es 23030, el mismo que el mapa de
# secciones. En la sesión 4 veremos qué pasa si nos equivocamos aquí.

casos <- st_as_sf(casos, coords = c("long", "lat"), crs = 23030)

head(casos)    # la tabla tiene ahora una columna "geometry" con los puntos

# Paso 4. Dibujar los casos sobre las secciones censales.

mf_map(granada, col = "grey90", border = "white")
mf_map(casos, pch = 20, cex = 0.8, col = "blue", add = TRUE)
mf_title("Domicilio de los casos de cáncer. Granada capital")


#================================================================
# 6. MAPA DE CALOR: ¿DÓNDE SE AGRUPAN LOS CASOS?
#================================================================
# PREGUNTA DE SALUD
#   ¿Hay zonas de la ciudad donde los casos se concentran más?
#
# DATOS
#   Los mismos casos y secciones del apartado 5.
#
# TIPO DE MAPA
#   Mapa de calor. Con muchos puntos, el mapa de puntos se satura y es
#   difícil ver dónde hay más. La idea es sencilla: cubrimos la ciudad
#   con una cuadrícula y, para cada celda, contamos cuántos casos
#   residen a menos de 500 metros. Las celdas con más casos alrededor
#   se pintan con colores más intensos.
#----------------------------------------------------------------

# Paso 1. Crear la cuadrícula.
# st_make_grid() cubre la extensión del mapa de Granada con celdas
# cuadradas de 50 x 50 metros (cellsize = 50, en metros porque el mapa
# está en coordenadas UTM). st_sf() la convierte en un mapa con tabla,
# al que podremos añadir columnas.
# El tamaño de la celda solo afecta a lo fino que se ve el mapa: con
# celdas grandes sale "pixelado" y con celdas muy pequeñas el cálculo
# tarda más sin ganar nada. Lo que decide el resultado es el radio de
# 500 m del paso 2. Como guía, la celda debe ser bastante más pequeña
# que ese radio (aquí, 10 veces menor).

cuadricula <- st_sf(geometry = st_make_grid(granada, cellsize = 50))

nrow(cuadricula)    # número de celdas

# Paso 2. Contar los casos a menos de 500 m del centro de cada celda.
# st_centroid() obtiene el punto central de cada celda.
# st_is_within_distance() busca, para cada centro, qué casos están a
# menos de 500 m, y lengths() cuenta cuántos son.

centros_celda <- st_centroid(cuadricula)
cuadricula$casos_500m <- lengths(st_is_within_distance(centros_celda, casos, dist = 500))

# Paso 3. Quedarnos solo con las celdas que tienen algún caso cerca,
# para no tapar el mapa de fondo con celdas vacías.

calor <- filter(cuadricula, casos_500m > 0)

# Paso 4. Dibujar: secciones de fondo, celdas coloreadas según el
# número de casos (coropletas otra vez, ahora sobre la cuadrícula) y
# los casos encima. border = NA quita el borde de las celdas.

mf_map(granada, col = "grey95", border = "grey80")
mf_map(calor,
       var       = "casos_500m",
       type      = "choro",
       breaks    = c(1, 3, 6, 12, 25),
       pal       = "Reds",
       border    = NA,
       leg_pos   = "left",
       leg_title = "Casos a\nmenos de 500 m",
       leg_val_rnd = 0,
       add       = TRUE)
mf_map(casos, pch = 20, cex = 0.4, col = "black", add = TRUE)
mf_title("Mapa de calor de los casos. Granada capital")

# Para interpretar: el radio de 500 m decide el resultado. Con un
# radio pequeño el mapa casi reproduce cada caso, y con uno grande se
# difumina todo. Y lo más importante: más casos no significa más
# riesgo. Donde vive más gente habrá más casos. Para hablar de riesgo
# hay que tener en cuenta la población de cada zona, algo que se verá
# en el bloque de epidemiología espacial.


#================================================================
# 7. SUPERFICIE CONTINUA: EXPOSICIÓN AL TRÁFICO
#================================================================
# PREGUNTA DE SALUD
#   ¿Qué nivel de tráfico hay en cada zona de la ciudad? La
#   contaminación por tráfico es un factor de riesgo de cáncer de
#   pulmón, y querríamos saber a qué nivel de tráfico está expuesto
#   cada domicilio.
#
# DATOS
#   130 puntos de medida de tráfico de Granada con la intensidad media
#   diaria (IMD, vehículos al día) en 2008 (Shapefiles/Puntos_de_medida).
#
# TIPO DE MAPA
#   Superficie continua. Solo conocemos el tráfico en 130 puntos, pero
#   queremos un valor para cualquier lugar de la ciudad. Lo estimamos
#   por interpolación: el valor de cada celda es una media de las
#   mediciones cercanas, en la que pesan más las más próximas (método
#   IDW, "distancia inversa ponderada").
#----------------------------------------------------------------

# Paso 1. Leer los puntos de medida.
# La columna IMD2008 viene guardada como texto. as.numeric() la
# convierte en número para poder hacer cálculos con ella.

trafico <- st_read("Shapefiles/Puntos_de_medida.shp", quiet = TRUE)
trafico$IMD2008 <- as.numeric(trafico$IMD2008)

summary(trafico$IMD2008)    # resumen: mínimo, máximo, mediana...

# Paso 2. Crear una cuadrícula de 50 x 50 m sobre la zona donde hay
# puntos de medida (como en el apartado 6).

cuadricula_traf <- st_sf(geometry = st_make_grid(trafico, cellsize = 50))

# Paso 3. Estimar el tráfico en el centro de cada celda.
# idw() necesita: la variable a estimar (IMD2008 ~ 1), dónde se midió
# (locations = trafico) y dónde queremos estimarla (newdata = los
# centros de las celdas). El resultado está en la columna var1.pred,
# que copiamos a la cuadrícula con el nombre "imd".

estimacion <- idw(IMD2008 ~ 1,
                  locations = trafico,
                  newdata   = st_centroid(cuadricula_traf))
cuadricula_traf$imd <- estimacion$var1.pred

# Paso 4. Dibujar la superficie, con las secciones y los puntos de
# medida encima como referencia.

mf_map(cuadricula_traf,
       var       = "imd",
       type      = "choro",
       breaks    = c(1000, 2000, 4000, 6000, 10000, 17000),
       pal       = "YlOrRd",
       border    = NA,
       leg_pos   = "left",
       leg_title = "Vehículos\nal día",
       leg_val_rnd = 0)
mf_map(granada, col = NA, border = "white", lwd = 0.5, add = TRUE)
mf_map(trafico, pch = 20, cex = 0.5, col = "black", add = TRUE)
mf_title("Intensidad media diaria de tráfico. Granada, 2008")

# Para interpretar: la estimación es fiable cerca de los puntos de
# medida y lo es menos lejos de ellos. Hay métodos más elaborados
# (kriging) que también calculan el error de la estimación. Se verán
# en el bloque de epidemiología espacial.


#================================================================
# 8. MAPA INTERACTIVO: LOS CASOS SOBRE UN CALLEJERO
#================================================================
# PREGUNTA
#   ¿En qué calles y barrios están exactamente los casos?
#
# DATOS
#   Los casos del apartado 5.
#
# TIPO DE MAPA
#   Mapa interactivo: se puede acercar, alejar y pinchar en cada punto
#   para ver sus datos, sobre un callejero de fondo. Necesita conexión
#   a internet para descargar el callejero.
#----------------------------------------------------------------

# Elegimos los mapas de fondo disponibles (se cambian con el botón de
# capas, arriba a la izquierda del mapa). Usamos estos porque no piden
# clave de acceso.

mapviewOptions(basemaps = c("OpenStreetMap", "Esri.WorldImagery"))

# Dibujamos los casos. El mapa aparece en la pestaña "Viewer".

mapview(casos, col.regions = "red", layer.name = "Casos de cáncer", legend = FALSE)


#================================================================
# 9. GUARDAR UN MAPA COMO IMAGEN
#================================================================
# Para usar un mapa en una presentación o un artículo, lo guardamos
# como imagen PNG en la carpeta "Figuras".
#   1. dir.create() crea la carpeta (si ya existe, no hace nada).
#   2. mf_png() abre el fichero de imagen. Desde ese momento, lo que
#      dibujemos va al fichero, no a la pantalla.
#   3. Dibujamos el mapa con las mismas instrucciones del apartado 2.
#   4. dev.off() cierra el fichero y lo guarda. En la consola aparece
#      un pequeño mensaje (por ejemplo "null device 1"): es normal.

dir.create("Figuras", showWarnings = FALSE)

mf_png(peninsula, filename = "Figuras/mortalidad_cancer_2016.png", width = 1200)
mf_map(peninsula,
       var       = "tasa_bruta",
       type      = "choro",
       breaks    = c(150, 200, 250, 300, 350, 400),
       pal       = "Oranges",
       leg_pos   = "right",
       leg_title = "Tasa bruta\n(x100.000)",
       leg_val_rnd = 0)
mf_title("Mortalidad por cáncer. España, 2016")
mf_credits("Fuente: INE. Defunciones según la causa de muerte")
dev.off()

# Busca el fichero en la carpeta Figuras, en la pestaña "Files".
