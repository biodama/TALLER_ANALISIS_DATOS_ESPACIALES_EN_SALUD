#################################################################
# Taller "Análisis de datos espaciales en salud" (CIBERESP 2026)
# Sesión 4. Manipulación e interacción entre capas
# Miguel Rodríguez Barranco (EASP, ibs.GRANADA, CIBERESP)
#################################################################
#
# CÓMO USAR ESTE SCRIPT
#   Igual que en la sesión anterior: ejecuta las líneas de una en una
#   (o por bloques) con Ctrl + Enter (Cmd + Enter en Mac) y fíjate en
#   la consola y en la pestaña "Plots".
#
# EL SUPUESTO DE TODA LA SESIÓN
#   La privación socioeconómica se asocia con peor salud. En cáncer,
#   con diferencias en el diagnóstico, el acceso a los servicios
#   sanitarios y la supervivencia. Nos planteamos esta pregunta:
#
#     En Granada capital, ¿los casos de cáncer que viven en zonas más
#     desfavorecidas tienen peor acceso a su centro de salud?
#
#   Para responderla tenemos que cruzar varias capas, y cada paso de
#   la sesión es una operación distinta entre capas:
#
#    1. Poner todas las capas en el mismo sistema de referencia
#    2. Añadir privación y población a cada sección censal .. unir tabla y capa
#    3. Saber el nivel de privación de cada caso ............ intersección
#    4. Obtener el contorno del municipio y los distritos .... unión
#    5. Localizar los centros de salud del municipio ........ selección
#    6. Medir la distancia de cada caso a su centro ......... distancias
#    7. Dibujar el área a pie de cada centro (500 m) ........ buffers
#    8. Ver qué parte de cada sección cubre esa área ........ división
#    9. Casos y tasa de cada distrito ........................ de puntos a polígonos
#   10. Guardar el resultado
#
#   AVISO: la población, el índice de privación y los centros de salud
#   son datos reales, pero los 78 casos son ficticios. Los resultados no
#   permiten sacar conclusiones: el objetivo es aprender el procedimiento,
#   que sería el mismo con casos reales.
#
# DATOS (todos de Granada capital)
#   - Secciones censales (Shapefiles/SeccCensalGranadaCensoNov2001_ED50)
#   - Índice de privación por sección censal (Datos/EDI GRX.csv)
#   - Población por sección censal a 1 de enero de 2004, del Padrón
#     Municipal del INE (Datos/Poblacion GRX 2004.csv)
#   - Casos de cáncer, los de la sesión anterior (Datos/Casos.csv)
#   - Centros sanitarios de Andalucía (Datos/Centros sanitarios.csv)
#################################################################


#================================================================
# 0. PREPARACIÓN: CARGAR LOS PAQUETES
#================================================================

library(sf)       # leer y manejar mapas (capas geográficas)
library(dplyr)    # manejar tablas: filtrar filas, unir tablas, resumir
library(mapsf)    # dibujar mapas temáticos


#================================================================
# 1. PONER TODAS LAS CAPAS EN EL MISMO SISTEMA DE REFERENCIA
#================================================================
# PARA QUÉ
#   Vamos a asignar a cada caso la sección censal en la que vive y,
#   con ella, su nivel de privación. Si las capas no están en el mismo
#   sistema de referencia (CRS), los casos caerán en secciones que no
#   son las suyas y les asignaremos un nivel de privación equivocado.
#
# LO QUE HAY QUE SABER
#   En España conviven dos sistemas:
#     - ED50 / UTM zona 30N (código 23030): el antiguo. Muchas capas y
#       bases de datos todavía lo usan.
#     - ETRS89 / UTM zona 30N (código 25830): el oficial desde 2007.
#   Los dos miden en metros, pero un mismo punto tiene coordenadas
#   distintas en cada uno (en Granada, unos 235 m de diferencia).
#   Pasaremos todo al sistema oficial, ETRS89.
#----------------------------------------------------------------

# Paso 1. Leer las capas, como en la sesión anterior.

secciones <- st_read("Shapefiles/SeccCensalGranadaCensoNov2001_ED50.shp", quiet = TRUE)
granada   <- filter(secciones, codmun == "18087")    # Granada capital

casos <- read.csv2("Datos/Casos.csv")
casos <- st_as_sf(casos, coords = c("long", "lat"), crs = 23030)

centros <- read.csv2("Datos/Centros sanitarios.csv")
centros <- st_as_sf(centros, coords = c("long", "lat"), crs = 25830)

# Paso 2. Comprobar en qué sistema está cada capa.
# st_crs() informa del sistema de referencia y $Name muestra su nombre.

st_crs(granada)$Name    # ED50
st_crs(casos)$Name      # ED50
st_crs(centros)$Name    # ETRS89  <- distinto de los demás

# Si intentamos cruzar capas en sistemas distintos, R da un error.
# Prueba a quitar el # de la línea siguiente y ejecutarla:
# st_intersects(casos, centros)

# Paso 3. Transformar a ETRS89 las capas que están en ED50.
# st_transform() recalcula las coordenadas en el nuevo sistema. Las
# capas no se mueven en el mundo real: solo cambian los números que
# describen su posición.

granada <- st_transform(granada, 25830)
casos   <- st_transform(casos,   25830)

st_crs(granada) == st_crs(centros)    # TRUE: ya están en el mismo sistema

# Paso 4. ¿Y si nos equivocamos al declarar el sistema?
# Es un error frecuente y silencioso: R no avisa. Leemos los casos
# otra vez, pero diciendo (mal) que sus coordenadas están en ETRS89.

casos_mal <- read.csv2("Datos/Casos.csv")
casos_mal <- st_as_sf(casos_mal, coords = c("long", "lat"), crs = 25830)

# Dibujamos los casos bien colocados (azul) y mal colocados (rojo).
# El primer mapa que se dibuja (casos) fija la zona que se ve, así
# que el mapa queda ampliado a la zona donde están los casos.

mf_map(casos, pch = 20, cex = 1, col = "blue")
mf_map(granada, col = NA, border = "grey60", add = TRUE)
mf_map(casos_mal, pch = 4, cex = 1, col = "red", add = TRUE)
mf_title("Casos con el sistema bien (azul) y mal declarado (rojo)")

# Cada caso aparece desplazado unos 235 m: suficiente para que muchos
# queden en una sección que no es la suya. Lo comprobaremos en el
# apartado 3. A partir de aquí trabajamos con los casos bien colocados.


#================================================================
# 2. AÑADIR PRIVACIÓN Y POBLACIÓN A CADA SECCIÓN CENSAL
#================================================================
# PARA QUÉ
#   Para saber cómo de desfavorecida es cada zona de la ciudad y
#   cuánta gente vive en ella. La población nos permitirá más adelante
#   calcular tasas y medir la población con buen acceso.
#
# DATOS
#   - Una tabla con el índice de privación europeo (EDI) de cada
#     sección censal de Granada capital (Datos/EDI GRX.csv). Valores
#     más altos indican más privación.
#   - Una tabla con la población de cada sección a 1 de enero de 2004
#     (Datos/Poblacion GRX 2004.csv).
#
# QUÉ HACEMOS
#   Añadir las dos tablas al mapa de secciones con left_join(), como
#   hicimos con la mortalidad en la sesión anterior, y COMPROBAR que
#   todas las secciones han encontrado su valor.
#----------------------------------------------------------------

# Paso 1. Leer la tabla y mirar cómo es.
# str() muestra el tipo de cada columna.

edi <- read.csv2("Datos/EDI GRX.csv")

str(edi)

# ID_SC es el código de sección y R lo ha leído como número (int).
# En el mapa, el código de sección (codsecc) es texto (chr). Para
# unirlos tienen que ser del mismo tipo: convertimos ID_SC en texto.

edi$ID_SC <- as.character(edi$ID_SC)

# Paso 2. Unir la tabla al mapa por el código de sección.

granada <- left_join(granada, edi, by = c("codsecc" = "ID_SC"))

# Paso 3. Comprobar el enlace.
# Si una sección no hubiera encontrado su código en la tabla, su EDI
# quedaría vacío (NA). is.na() detecta los vacíos y sum() los cuenta.
# Hay que hacerlo SIEMPRE después de unir una tabla: un error en los
# códigos no da ningún aviso, simplemente deja huecos.

sum(is.na(granada$edi))    # 0: todas las secciones tienen su EDI

# Paso 4. Lo mismo con la población. Esta vez leemos el código como
# texto desde el principio con colClasses, como en la sesión anterior.

poblacion <- read.csv2("Datos/Poblacion GRX 2004.csv",
                       colClasses = c(ID_SC = "character"))

granada <- left_join(granada, poblacion, by = c("codsecc" = "ID_SC"))

sum(is.na(granada$poblacion))    # 0: todas las secciones tienen su población
sum(granada$poblacion)           # población total de Granada capital

# Paso 5. Mapa de privación (coropletas, como en la sesión anterior).
# Con breaks = "quantile" cada color agrupa el 20% de las secciones:
# del 20% menos privado al 20% más privado.

mf_map(granada,
       var         = "edi",
       type        = "choro",
       breaks      = "quantile",
       nbreaks     = 5,
       pal         = "Purples",
       leg_pos     = "left",
       leg_title   = "EDI\n(quintiles)",
       leg_val_rnd = 1)
mf_title("Índice de privación por sección censal. Granada capital")

# Paso 6. Clasificar las secciones en dos grupos para poder comparar.
# La mediana es el valor que deja la mitad de las secciones por debajo
# y la otra mitad por encima. ifelse() asigna "Más privada" a las que
# superan la mediana y "Menos privada" al resto.

granada$privacion <- ifelse(granada$edi > median(granada$edi),
                            "Más privada", "Menos privada")

table(granada$privacion)    # mitad y mitad


#================================================================
# 3. SABER EL NIVEL DE PRIVACIÓN DE CADA CASO (INTERSECCIÓN)
#================================================================
# PARA QUÉ
#   Los casos son puntos y el EDI está en las secciones (polígonos).
#   Necesitamos pasar a cada caso el EDI de la sección en la que vive.
#
# QUÉ HACEMOS
#   Una unión espacial: es como left_join(), pero en lugar de
#   emparejar por un código, empareja por la posición en el mapa. A
#   cada caso le añadimos los datos de la sección dentro de la cual cae.
#----------------------------------------------------------------

# Paso 1. Unión espacial con st_join().
# select() elige qué columnas de las secciones pasamos a los casos.

casos <- st_join(casos, select(granada, codsecc, edi, privacion))

head(casos)    # cada caso tiene ahora su sección, su EDI y su grupo

sum(is.na(casos$codsecc))    # 0: todos los casos han caído en una sección

# Paso 2. Cuántos casos hay en cada grupo de privación.

table(casos$privacion)

# Paso 3. Volvemos al error del apartado 1. Si hubiéramos usado los
# casos mal colocados, ¿cuántos habrían recibido una sección distinta?

casos_mal <- st_join(casos_mal, select(granada, codsecc))

sum(casos$codsecc != casos_mal$codsecc)    # casos asignados a otra sección

# Más de la mitad de los casos habrían recibido el EDI de otra sección.
# Ya no volvemos a usar casos_mal.


#================================================================
# 4. CONTORNO DEL MUNICIPIO Y DISTRITOS (UNIÓN DE POLÍGONOS)
#================================================================
# PARA QUÉ
#   - El contorno del municipio nos servirá para seleccionar los
#     centros de salud que están dentro de él (apartado 5).
#   - Los distritos agrupan muchas secciones. Con tan pocos casos, por
#     sección habría casi siempre 0 o 1. Por distrito los recuentos
#     son mayores y las tasas más estables (apartado 9).
#
# QUÉ HACEMOS
#   "Disolver" o unir polígonos: juntar varias secciones en uno solo,
#   borrando las fronteras interiores.
#----------------------------------------------------------------

# Paso 1. Contorno del municipio: unir todas las secciones en una.
# st_union() junta todos los polígonos de la capa en uno solo.

municipio <- st_union(granada)

mf_map(granada, col = "grey90", border = "white")
mf_map(municipio, col = NA, border = "black", lwd = 2, add = TRUE)
mf_title("Secciones censales y contorno del municipio")

# Paso 2. Distritos: unir las secciones de cada distrito.
# El código de sección tiene 10 cifras con esta estructura:
#   18 087 01 001  =  provincia, municipio, distrito, sección
# substr() extrae del código las cifras 6 y 7, que son el distrito.

granada$distrito <- substr(granada$codsecc, 6, 7)

# group_by() agrupa las secciones por distrito y summarise() resume
# cada grupo en una sola fila. En una capa geográfica, summarise()
# además une los polígonos de cada grupo. De paso, calculamos el EDI
# medio de cada distrito con mean() y su población sumando la de sus
# secciones con sum().

distritos <- group_by(granada, distrito)
distritos <- summarise(distritos,
                       edi_medio = mean(edi),
                       poblacion = sum(poblacion))

distritos    # una fila por distrito

mf_map(distritos,
       var         = "edi_medio",
       type        = "choro",
       breaks      = "quantile",
       nbreaks     = 4,
       pal         = "Purples",
       leg_pos     = "left",
       leg_title   = "EDI medio",
       leg_val_rnd = 1)
mf_label(distritos, var = "distrito", halo = TRUE)    # número de distrito
mf_title("Índice de privación medio por distrito. Granada capital")


#================================================================
# 5. LOCALIZAR LOS CENTROS DE SALUD DEL MUNICIPIO (SELECCIÓN)
#================================================================
# PARA QUÉ
#   Para medir el acceso necesitamos los centros de salud de Granada
#   capital, y la tabla trae todos los centros sanitarios de Andalucía.
#
# QUÉ HACEMOS
#   Dos selecciones:
#     - por atributos (lo que pone la tabla): solo los centros de salud
#     - por localización (dónde están): solo los que caen dentro del
#       municipio
#----------------------------------------------------------------

# Paso 1. Selección por atributos, con filter() como hasta ahora.

centros_salud <- filter(centros, tipocentro == "CENTROS DE SALUD")

nrow(centros_salud)    # centros de salud de toda Andalucía

# Paso 2. Selección por localización.
# st_filter() se queda con los elementos de una capa que tocan a otra:
# aquí, los centros de salud que caen dentro del municipio.

centros_salud <- st_filter(centros_salud, municipio)

nrow(centros_salud)    # centros de salud de Granada capital

mf_map(granada, col = "grey90", border = "white")
mf_map(centros_salud, pch = 15, cex = 1.2, col = "darkgreen", add = TRUE)
mf_title("Centros de salud. Granada capital")


#================================================================
# 6. DISTANCIA DE CADA CASO A SU CENTRO DE SALUD
#================================================================
# PARA QUÉ
#   La distancia al centro de salud más cercano es una forma sencilla
#   de medir el acceso a la atención primaria. Es la variable que
#   compararemos entre zonas más y menos privadas.
#
# QUÉ HACEMOS
#   Para cada caso, buscar el centro de salud más cercano y medir la
#   distancia en línea recta hasta él.
#----------------------------------------------------------------

# Paso 1. Buscar el centro más cercano a cada caso.
# st_nearest_feature() devuelve, para cada caso, el número de fila del
# centro de salud más próximo.

cercano <- st_nearest_feature(casos, centros_salud)

casos$centro_salud <- centros_salud$centro[cercano]    # guardamos su nombre

# Paso 2. Medir la distancia de cada caso a ese centro.
# st_distance() mide distancias en las unidades del sistema de
# referencia: metros. by_element = TRUE mide caso a caso (el caso 1
# con su centro, el 2 con el suyo...). as.numeric() quita la etiqueta
# de unidades para poder operar con el resultado.

casos$distancia <- as.numeric(st_distance(casos, centros_salud[cercano, ],
                                          by_element = TRUE))

summary(casos$distancia)    # distancias en metros

# Paso 3. Dibujar los casos coloreados según la distancia.
# type = "choro" también sirve para puntos: los colorea según su valor.
# pch = 21 es un círculo con borde (border) y relleno de color.

mf_map(granada, col = "grey90", border = "white")
mf_map(centros_salud, pch = 15, cex = 1.2, col = "darkgreen", add = TRUE)
mf_map(casos,
       var         = "distancia",
       type        = "choro",
       breaks      = c(0, 250, 500, 1000, 4000),
       pal         = "Reds",
       pch         = 21,
       cex         = 1.2,
       border      = "black",
       leg_pos     = "left",
       leg_title   = "Distancia al centro\nde salud (m)",
       leg_val_rnd = 0,
       add         = TRUE)
mf_title("Distancia de cada caso a su centro de salud más cercano")

# Paso 4. Comparar la distancia según la privación de la zona.
# Para resumir no necesitamos el mapa, solo la tabla: st_drop_geometry()
# quita la columna geometry. Después agrupamos por nivel de privación y
# calculamos, para cada grupo, el número de casos (n()) y la distancia
# mediana (median()).

tabla_casos <- st_drop_geometry(casos)
tabla_casos <- group_by(tabla_casos, privacion)
summarise(tabla_casos,
          casos             = n(),
          distancia_mediana = median(distancia))

# Para interpretar: es distancia en línea recta. La distancia real por
# calles o el tiempo de viaje requieren un mapa de la red viaria.


#================================================================
# 7. ÁREA A PIE DE CADA CENTRO DE SALUD (BUFFERS)
#================================================================
# PARA QUÉ
#   La distancia del apartado 6 es una medida para cada caso (punto).
#   Ahora queremos una ZONA: el área a menos de 500 m de un centro de
#   salud, que se puede recorrer a pie en unos 6 o 7 minutos. Esa zona
#   es un polígono, y con ella podremos medir qué parte de cada
#   sección queda bien cubierta (apartado 8).
#
# QUÉ HACEMOS
#   Dibujar un círculo de 500 m alrededor de cada centro de salud
#   (área de influencia o "buffer").
#----------------------------------------------------------------

# Paso 1. Crear el círculo de 500 m alrededor de cada centro.
# st_buffer() dibuja un círculo de radio dist (en metros) alrededor de
# cada punto. Como los círculos se solapan, st_union() los junta en una
# sola zona (como hicimos con las secciones en el apartado 4).

area_500m <- st_buffer(centros_salud, dist = 500)
area_500m <- st_union(area_500m)

mf_map(granada, col = "grey90", border = "white")
mf_map(area_500m, col = "lightgreen", border = "darkgreen", add = TRUE)
mf_map(centros_salud, pch = 15, cex = 1.2, col = "darkgreen", add = TRUE)
mf_map(casos, pch = 20, cex = 0.8, col = "black", add = TRUE)
mf_title("Zona a menos de 500 m de un centro de salud")

# Paso 2. Comprobación: los casos que caen dentro de la zona deberían
# ser los mismos que tienen una distancia menor de 500 m en el
# apartado 6. st_intersects() comprueba, para cada caso, si toca la
# zona, y lengths() vale 1 si la toca y 0 si no.

dentro <- lengths(st_intersects(casos, area_500m))

sum(dentro)                  # casos dentro de la zona
sum(casos$distancia < 500)   # casos a menos de 500 m: el mismo número


#================================================================
# 8. QUÉ PARTE DE CADA SECCIÓN CUBRE EL ÁREA A PIE (DIVISIÓN)
#================================================================
# PARA QUÉ
#   Para medir el acceso de toda la POBLACIÓN, no solo de los casos:
#   qué parte de los habitantes de cada sección vive a menos de 500 m
#   de un centro de salud. Así podemos comparar las zonas más y menos
#   privadas, tengan casos o no.
#
# QUÉ HACEMOS
#   Recortar las secciones con el área del apartado 7: quedarnos con el
#   trozo de cada sección que cae dentro y ver qué porcentaje de su
#   superficie representa. No sabemos dónde vive exactamente cada
#   persona dentro de su sección, así que suponemos que la población
#   está repartida por igual: si el 40% de la superficie queda dentro,
#   el 40% de sus habitantes también.
#----------------------------------------------------------------

# Paso 1. Calcular la superficie de cada sección antes de recortarla.
# st_area() devuelve la superficie en metros cuadrados.

granada$area_total <- as.numeric(st_area(granada))

# Paso 2. Recortar.
# st_intersection() se queda con la parte de cada sección que está
# dentro del área a pie. Las secciones que no la tocan desaparecen.
# Los trozos conservan las columnas de su sección (entre ellas
# area_total). R muestra un aviso ("attribute variables are
# assumed..."): solo informa de eso, no es un error.

recorte <- st_intersection(granada, area_500m)

# Paso 3. Porcentaje de superficie cubierta de cada sección.
# round(..., 1) redondea a un decimal.

recorte$pct_cubierto <- round(as.numeric(st_area(recorte)) / recorte$area_total * 100, 1)

# Paso 4. Pasar el porcentaje a la capa de secciones.
# Usamos left_join() para tener el porcentaje en la sección entera y
# no solo en el trozo recortado. st_drop_geometry() quita la geometría
# del recorte para unirlo como una tabla normal. Las secciones que no
# tocan el área quedan vacías (NA) y les ponemos un 0.

granada <- left_join(granada,
                     select(st_drop_geometry(recorte), codsecc, pct_cubierto),
                     by = "codsecc")
granada$pct_cubierto[is.na(granada$pct_cubierto)] <- 0

mf_map(granada,
       var         = "pct_cubierto",
       type        = "choro",
       breaks      = c(0, 1, 25, 50, 75, 100),
       pal         = "Greens",
       leg_pos     = "left",
       leg_title   = "% a < 500 m de\nun centro de salud",
       leg_val_rnd = 0)
mf_map(centros_salud, pch = 15, cex = 1, col = "black", add = TRUE)
mf_title("Parte de cada sección a menos de 500 m de un centro de salud")

# Paso 5. Población que vive a menos de 500 m de un centro de salud.
# Aplicamos el porcentaje de superficie a la población de cada sección.

granada$pob_cubierta <- granada$poblacion * granada$pct_cubierto / 100

# Paso 6. Comparar según la privación de la sección: para cada grupo,
# sumamos la población total y la población cubierta, y calculamos qué
# porcentaje de la población está cubierta.

tabla_secciones <- st_drop_geometry(granada)
tabla_secciones <- group_by(tabla_secciones, privacion)
tabla_secciones <- summarise(tabla_secciones,
                             poblacion    = sum(poblacion),
                             pob_cubierta = sum(pob_cubierta))
tabla_secciones$pct_cubierta <- round(tabla_secciones$pob_cubierta /
                                        tabla_secciones$poblacion * 100, 1)
tabla_secciones

# Para interpretar: suponer que la población se reparte por igual
# dentro de cada sección es una simplificación. Funciona bien en las
# secciones del centro, pequeñas y densas. En las grandes secciones de
# la periferia (con huerta o monte) puede no cumplirse.


#================================================================
# 9. CASOS Y TASA DE CADA DISTRITO (DE PUNTOS A POLÍGONOS)
#================================================================
# PARA QUÉ
#   Para ver si el cáncer es más frecuente en los distritos más
#   desfavorecidos. Un número de casos no basta: un distrito con más
#   habitantes tendrá más casos. Hay que dividir entre la población
#   y calcular una tasa.
#
# QUÉ HACEMOS
#   Contar cuántos casos (puntos) caen dentro de cada distrito
#   (polígono) y dividir entre su población.
#----------------------------------------------------------------

# Paso 1. Contar los casos de cada distrito.
# st_intersects() busca, para cada distrito, qué casos caen dentro,
# y lengths() cuenta cuántos son.

distritos$n_casos <- lengths(st_intersects(distritos, casos))

# Paso 2. Calcular la tasa bruta por 100.000 habitantes.

distritos$tasa <- round(distritos$n_casos / distritos$poblacion * 100000, 1)

# Paso 3. Ver la tabla ordenada de menor a mayor privación.
# arrange() ordena las filas según una columna.

arrange(st_drop_geometry(distritos), edi_medio)

# Paso 4. Mapa de la tasa por distrito (coropletas, porque es una
# tasa) con el número de distrito como etiqueta.

mf_map(distritos,
       var         = "tasa",
       type        = "choro",
       breaks      = "quantile",
       nbreaks     = 4,
       pal         = "Reds",
       leg_pos     = "left",
       leg_title   = "Tasa bruta\n(x100.000)",
       leg_val_rnd = 0)
mf_label(distritos, var = "distrito", halo = TRUE)
mf_title("Tasa bruta de casos por distrito. Granada capital")

# Compara este mapa con el de privación del apartado 4.

# Para interpretar: con tan pocos casos, uno más o uno menos cambia
# mucho la tasa de un distrito. Además, la tasa bruta no tiene en
# cuenta la edad. Las tasas ajustadas por edad, las razones de
# incidencia estandarizadas y los métodos para estabilizar tasas de
# áreas pequeñas se verán en el bloque de epidemiología espacial.


#================================================================
# 10. GUARDAR EL RESULTADO
#================================================================
# Las capas que hemos creado solo existen mientras R está abierto.
# Para conservarlas, las guardamos en un fichero GeoPackage (.gpkg):
# un único fichero, en lugar de los cuatro del shapefile.
# append = FALSE sobrescribe el fichero si ya existe.

st_write(granada,   "Datos/secciones_granada.gpkg", append = FALSE)  # con EDI, población y acceso
st_write(casos,     "Datos/casos_granada.gpkg",     append = FALSE)  # con EDI y distancia
st_write(distritos, "Datos/distritos_granada.gpkg", append = FALSE)  # con EDI, casos y tasa

# Se pueden leer de nuevo con st_read(), igual que un shapefile.
